# SPI---bus-by-arduino
Wead and Write using SPI-protocole (dealing with digital potentiometer)
