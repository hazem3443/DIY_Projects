# Micro-SD-card
storing sensor data on SD-Card
