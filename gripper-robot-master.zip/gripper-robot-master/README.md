# gripper-robot
gripper robot controled by bluetooth
