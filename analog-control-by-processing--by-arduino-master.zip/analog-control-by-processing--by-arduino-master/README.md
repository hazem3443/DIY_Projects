# analog-control-by-processing
control window colour by potentiometer
