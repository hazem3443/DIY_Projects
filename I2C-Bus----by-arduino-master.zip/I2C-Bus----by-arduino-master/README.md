# I2C-Bus
read data from I2c device ( Temperature sensor ) 
