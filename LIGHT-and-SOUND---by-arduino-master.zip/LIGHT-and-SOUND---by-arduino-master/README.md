# LIGHT-and-SOUND
controling RGB leds with sound amplified signal
