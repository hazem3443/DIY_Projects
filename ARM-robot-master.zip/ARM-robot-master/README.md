# ARM-robot-by-arduino
arm robot by arduino using gyroscope to control  and data is transmitted by two ways bluetooth or RF
