%CodeStart--------------------------------------------------------
%Resetting MATLAB environment
  instrreset
  clear
  clc
%Creating UDP object
  UDPComIn=udp('172.26.0.101','LocalPort',12345);
  set(UDPComIn,'DatagramTerminateMode','off')
%Opening UDP communication
  fopen(UDPComIn);
%Reading data
  while 1
    data=fscanf(UDPComIn);
    disp(data)
  end
%Closing UDP communication
  fclose(UDPComIn);
%Deleting UDP communication
  delete(UDPComIn)
%CodeEnd---------------------------------------------------------