# LCD
Writing on LCD and show sensor value
