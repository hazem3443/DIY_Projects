# GPS-TRACKER
it will store your location on a SD-card and you can check it later 
