# interrupts
using interrupts to blink RGB led with switch
